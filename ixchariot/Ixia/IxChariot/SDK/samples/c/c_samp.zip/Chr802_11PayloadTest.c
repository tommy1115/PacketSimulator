/****************************************************************
 *
 *  IxChariot API SDK              File: Chr802_11PayloadTest.c
 *
 *  This module contains code made available by Ixia on an AS IS
 *  basis.  Any one receiving the module is considered to be 
 *  licensed under Ixia copyrights to use the Ixia-provided 
 *  source code in any way he or she deems fit, including copying
 *  it, compiling it, modifying it, and redistributing it, with 
 *  or without modifications. No license under any Ixia patents
 *  or patent applications is to be implied from this copyright
 *  license.
 *
 *  A user of the module should understand that Ixia cannot 
 *  provide technical support for the module and will not be
 *  responsible for any consequences of use of the program.
 *
 *  Any notices, including this one, are not to be removed from
 *  the module without the prior written consent of Ixia.
 *
 *  For more information, contact:
 *
 *  Ixia
 *  26601 W. Agoura Rd. 
 *  Calabasas, CA 91302 USA
 *  Web:   http://www.ixiacom.com
 *  Phone: 818-871-1800
 *  Fax:   818-871-1805
 *
 *  General Information:
 *    e-mail: info@ixiacom.com
 *
 *  Technical Support:
 *    e-mail: support@ixiacom.com
 *
 *
 *  EXAMPLE: Endpoint Pairs Test
 *
 *  This program creates and runs a simple loopback test that
 *  uses the 802.11 and Script Embedded Payload features that
 *  were added in IxChariot 6.0.
 *
 *  All attributes of this test are defined by this program.
 *
 ****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * The header file which defines everything in the Chariot API:
 * functions, constants, etc.
 */
#include "chrapi.h"

/*
 * Local function to print information about errors.
 */
static void
show_error(
    CHR_HANDLE handle,
    CHR_API_RC code,
    CHR_STRING where);

/*
 * Data for the test:
 * Change these for your local network if desired.
 */
static
CHR_STRING e1 = "localhost";
static
CHR_STRING e2 = "localhost";
static
CHR_STRING script   = "c:/Program Files/Ixia/IxChariot/Scripts/Throughput.scr";
static
CHR_STRING testfile = "Chr802_11PayloadTest.tst";
static
CHR_COUNT timeout   = 120;  /* 2 minutes in seconds */
static
CHR_STRING sendDataTypeName = "send_datatype";
static
CHR_STRING embeddedPayload  = "This is a sample\0embedded payload";

/**************************************************************
 *
 * Program main
 *
 * If the return code from any Chariot API function call
 * is not CHR_OK, the show_error() function is called to
 * display information about what happened then exit.
 *
 **************************************************************/

void main()
{
    /*
     * The object handles we'll need
     */
    CHR_TEST_HANDLE test = (CHR_TEST_HANDLE)NULL;
    CHR_PAIR_HANDLE pair = (CHR_PAIR_HANDLE)NULL;

    /*
     * Variables and buffers for the attributes and results
     */
    CHR_LENGTH            len;
    CHR_FLOAT             rssi;
    CHR_CHAR              bssid[CHR_BSSID_SIZE];
    CHR_TIMINGREC_HANDLE  timingRec;

    /*
     * Buffer for extended error info for initialization
     */
    char errorInfo[CHR_MAX_ERROR_INFO];

    /*
     * Chariot API return code
     */
    CHR_API_RC rc;


    /* Initialize the Chariot API. */
    rc = CHR_api_initialize(CHR_DETAIL_LEVEL_ALL, errorInfo,
                            CHR_MAX_ERROR_INFO, &len);
    if (CHR_OK != rc) {
        /*
         * Because initialization failed, we can't
         * ask the API for the message for this
         * return code, so we can't call our
         * show_error() function. Instead, we'll
         * print what we do know before exiting.
         */
        printf("Initialization failed: rc = %d\n", rc);
        printf("Extended error info:\n%s\n", errorInfo);
    }

    /* Create a new test. */
    if (CHR_OK == rc) {
        printf("Create the test...\n");
        rc = CHR_test_new(&test);
        if (rc != CHR_OK) {
            show_error((CHR_HANDLE)NULL, rc, "test_new");
        }
    }

    /* Create a new pair. */
    if (CHR_OK == rc) {
        printf("Create the pair...\n");
        rc = CHR_pair_new(&pair);
        if (rc != CHR_OK) {
            show_error((CHR_HANDLE)NULL, rc, "pair_new");
        }
    }

    /* Define the attributes of the pair. */
    if (CHR_OK == rc) {
        printf("Set required pair attributes...\n");
        rc = CHR_pair_set_e1_addr(pair, e1, strlen(e1));
        if (rc != CHR_OK) {
            show_error(pair, rc, "pair_set_e1_addr");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_pair_set_e2_addr(pair, e2, strlen(e2));
        if (rc != CHR_OK) {
            show_error(pair, rc, "pair_set_e2_addr");
        }
    }

    /* Define a script for use in the test. */
    if (CHR_OK == rc) {
        printf("Use a script...\n");
        rc = CHR_pair_use_script_filename(
            pair,
            script,
            strlen(script));
        if (rc != CHR_OK) {
            show_error(pair, rc, "pair_use_script_filename");
        }
    }

    /* Set the Script Embedded Payload. */
    if (CHR_OK == rc) {
        printf("Set the Script Embedded Payload...\n");
        rc = CHR_pair_set_script_embedded_payload(
            pair,
            sendDataTypeName,
            strlen(sendDataTypeName),
            embeddedPayload,
            33); /* we didn't use strlen because the embedded payload is a binary buffer that contains the \0 character */
        if (rc != CHR_OK) {
            show_error(pair, rc, "pair_set_script_embedded_payload");
        }
    }

    /* Add the pair to the test. */
    if (CHR_OK == rc) {
        printf("Add the pair to the test...\n");
        rc = CHR_test_add_pair(test, pair);
        if (rc != CHR_OK) {
            show_error(test, rc, "test_add_pair");
        }
    }

    /* Run the test */
    if (CHR_OK == rc) {
        printf("Run the test...\n");
        rc = CHR_test_start(test);
        if (rc != CHR_OK) {
            show_error(test, rc, "test_start");
        }
    }

    /* Wait for the test to stop before we can look
     * at the results from it. We'll wait for 2 minutes here,
     * then call it an error if it has not yet stopped.
     */
    if (CHR_OK == rc) {
        printf("Wait for the test to stop...\n");
        rc = CHR_test_query_stop(test, timeout);
        if (rc != CHR_OK) {
            show_error(test, rc, "test_query_stop");
        }
    }

    /* Use the 802.11 feature to get the RSSI and BSSID values.
     * Note that these values are retrieved by Endpoint 1 for     
     * regular scripts and by Endpoint 2 for streaming scripts.
     */
       
    /* Print the average, min and max values of RSSI */
    if (CHR_OK == rc) {
        rc = CHR_pair_results_get_average(
            pair,
            CHR_RESULTS_RSSI_E1,
            &rssi);
        if (CHR_OK == rc) {
            printf("Average RSSI for Endpoint 1: %d dBm\n", (int)rssi);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            /* there are some cases (no 802.11 card or 
             * running a streaming script) when Endpoint 1
             * will not retrieve a valid RSSI
             */
            printf("Average RSSI for Endpoint 1: N/A\n");
            rc = CHR_OK; /* in this case, this is not really an error */
        }
        else {
            show_error(pair, rc, "pair_results_get_average RSSI_E1");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_pair_results_get_minimum(
            pair,
            CHR_RESULTS_RSSI_E1,
            &rssi);
        if (CHR_OK == rc) {
            printf("Minimum RSSI for Endpoint 1: %d dBm\n", (int)rssi);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("Minimum RSSI for Endpoint 1: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "pair_results_get_minimum RSSI_E1");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_pair_results_get_maximum(
            pair,
            CHR_RESULTS_RSSI_E1,
            &rssi);
        if (CHR_OK == rc) {
            printf("Maximum RSSI for Endpoint 1: %d dBm\n", (int)rssi);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("Maximum RSSI for Endpoint 1: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "pair_results_get_maximum RSSI_E1");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_pair_results_get_average(
            pair,
            CHR_RESULTS_RSSI_E2,
            &rssi);
        if (CHR_OK == rc) {
            printf("Average RSSI for Endpoint 2: %d dBm\n", (int)rssi);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("Average RSSI for Endpoint 2: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "pair_results_get_average RSSI_E2");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_pair_results_get_minimum(
            pair,
            CHR_RESULTS_RSSI_E2,
            &rssi);
        if (CHR_OK == rc) {
            printf("Minimum RSSI for Endpoint 2: %d dBm\n", (int)rssi);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("Minimum RSSI for Endpoint 2: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "pair_results_get_minimum RSSI_E2");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_pair_results_get_maximum(
            pair,
            CHR_RESULTS_RSSI_E2,
            &rssi);
        if (CHR_OK == rc) {
            printf("Maximum RSSI for Endpoint 2: %d dBm\n", (int)rssi);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("Maximum RSSI for Endpoint 2: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "pair_results_get_maximum RSSI_E2");
        }
    }

    /* Get the RSSI and BSSID values of the first timing record */
    if (CHR_OK == rc) {
        rc = CHR_pair_get_timing_record(
            pair,
            0,
            &timingRec);
        if (rc != CHR_OK) {
            show_error(pair, rc, "pair_get_timing_record");
        }
    }

    if (CHR_OK == rc) {
        CHR_LONG rssi_value;
        printf("RSSI and BSSID values for the first timing record:\n");
        rc = CHR_timingrec_get_e1_rssi(timingRec, &rssi_value);
        if (CHR_OK == rc) {
            printf("RSSI for Endpoint 1: %ld dBm\n", rssi_value);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("RSSI for Endpoint 1: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "timingrec_get_e1_rssi");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_timingrec_get_e1_bssid(
            timingRec,
            bssid,
            sizeof(bssid),
            &len);
        if (CHR_OK == rc) {
            printf("BSSID for Endpoint 1: %s\n", bssid);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("BSSID for Endpoint 1: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "timingrec_get_e1_bssid");
        }
    }

    if (CHR_OK == rc) {
        CHR_LONG rssi_value;
        rc = CHR_timingrec_get_e2_rssi(timingRec, &rssi_value);
        if (CHR_OK == rc) {
            printf("RSSI for Endpoint 2: %ld dBm\n", rssi_value);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("RSSI for Endpoint 2: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "timingrec_get_e2_rssi");
        }
    }

    if (CHR_OK == rc) {
        rc = CHR_timingrec_get_e2_bssid(
            timingRec,
            bssid,
            sizeof(bssid),
            &len);
        if (CHR_OK == rc) {
            printf("BSSID for Endpoint 2: %s\n", bssid);
        }
        else if (CHR_NO_SUCH_VALUE == rc) {
            printf("BSSID for Endpoint 2: N/A\n");
            rc = CHR_OK;
        }
        else {
            show_error(pair, rc, "timingrec_get_e2_bssid");
        }
    }

    /* Finally, let's save the test so we can look at it again. */
    /* We have to set the filename before we can save it.       */
    if (CHR_OK == rc) {
        printf("==========\nSave the test...\n");
        rc = CHR_test_set_filename(test,
                                   testfile, strlen(testfile));
        if (rc != CHR_OK) {
            show_error(test, rc, "test_set_filename");
        } else {
            rc = CHR_test_save(test);
        }

        if (rc != CHR_OK) {
            show_error(test, rc, "test_save");
        }
    }

    /* Explicitly free allocated resources. */
    if ( pair != (CHR_PAIR_HANDLE)NULL ) {
        CHR_pair_delete(pair);
    }
    if ( test != (CHR_TEST_HANDLE)NULL ) {
        CHR_test_delete(test);
    }

    /*
     * Exit test with success or error code.
     */
    exit(rc);
}


/**************************************************************
 *
 * Print information about an error and exit.
 *
 * Parameters: handle - what object had the error
 *             code   - the Chariot API return code
 *             where  - what function call failed
 *
 **************************************************************/

static void
show_error(
    CHR_HANDLE handle,
    CHR_API_RC code,
    CHR_STRING where)
{
    char       msg[CHR_MAX_RETURN_MSG];
    CHR_LENGTH msgLen;

    char       errorInfo[CHR_MAX_ERROR_INFO];
    CHR_LENGTH errorLen;

    CHR_API_RC rc;


    /*
     * Get the API message for this return code.
     */
    rc = CHR_api_get_return_msg(code, msg,
                                CHR_MAX_RETURN_MSG, &msgLen);
    if (rc != CHR_OK) {

        /* Could not get the message: show why */
        printf("%s failed\n", where);
        printf(
          "Unable to get message for return code %d, rc = %d\n",
           code, rc);
    }
    else {

        /* Tell the user about the error */
        printf("%s failed: rc = %d (%s)\n", where, code, msg);
    }

    /*
     * See if there is extended error information available.
     * It's meaningful only after some error returns. After 
     * failed "new" function calls, we don't have a handle so 
     * we cannot check for extended error information.
     */
    if ((code == CHR_OPERATION_FAILED || 
         code == CHR_OBJECT_INVALID ||
         code == CHR_APP_GROUP_INVALID) &&
         handle != (CHR_HANDLE)NULL) {

        rc = CHR_common_error_get_info(handle,
                                       CHR_DETAIL_LEVEL_ALL,
                                       errorInfo,
                                       CHR_MAX_ERROR_INFO,
                                      &errorLen);
        if (rc == CHR_OK) {

            /*
             * We can ignore all non-success return codes here
             * because most should not occur (the api's been
             * initialized, the handle is good, the buffer
             * pointer is valid, and the detail level is okay),
             * and the NO_SUCH_VALUE return code here means
             * there is no info available.
             */
            printf("Extended error info:\n%s\n", errorInfo);
        }
    }
}

