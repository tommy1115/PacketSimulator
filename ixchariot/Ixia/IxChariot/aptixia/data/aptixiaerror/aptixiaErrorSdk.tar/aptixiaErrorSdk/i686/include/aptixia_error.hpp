#ifndef __APTIXIA_ERROR_HPP__
#define __APTIXIA_ERROR_HPP__

#include <string>

using std::string;

namespace aptixia
{
  class Error
  {
    string errorId;
    string fileId;
	string errorMsg;

  public:

    string getErrorId();
    void setErrorId(const char *);

    string getFileId();
    void setFileId(const char *);

	string getErrorMessage();
	void setErrorMessage(string);
  };

 
 
    void ThrowServantError(
			   const char *,
			   const char *,
			   long,
			   aptixia::Error *,
			   const char *,
			   ...
			   );
  
}

#endif
